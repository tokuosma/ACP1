﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IaRegionListener : MonoBehaviour {
	void Start() {
	}

	void Update() {
	}

	void onEnterRegion (string data) {
	}

	void onExitRegion (string data) {
	}
}
